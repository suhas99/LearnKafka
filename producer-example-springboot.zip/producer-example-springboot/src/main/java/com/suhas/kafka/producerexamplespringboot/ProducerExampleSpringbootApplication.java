package com.suhas.kafka.producerexamplespringboot;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class ProducerExampleSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProducerExampleSpringbootApplication.class, args);
	}

}
