package com.suhas.kafka.producerexamplespringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducerExampleSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
